//Este componente deberia recibir por props y mostrar en pantalla la informacion
//que envia el usuario
import React from "react";
function Card({estudiante, programa}) {
  return (
    <div>
      <h2>Información del Estudiante</h2>
      <p>Nombre: {estudiante}</p>
      <p>Programa Académico: {programa}</p>
    </div>
  );
}

export default Card;
