import { useState } from "react"
import './index.css'
import Card from "./Card"
const CampusVirtual = () => {
    const [estudiante, setEstudiante] = useState("")
    const [programa, setPrograma] = useState("")
    const [mostrarTarjeta, setMostrarTarjeta] = useState(false);
    const onChangeEstudiante = (e) => setEstudiante(e.target.value);
    const onChangePrograma = (e) => setPrograma(e.target.value);

    const validateEstudiante = (estudiante) => {
      const withoutSpaces = estudiante.trim();
        if (withoutSpaces.length > 3) {
          return true;
          } else {
          return false;
          }
        };
    const validatePrograma = (programa) => {
      const withoutSpaces = programa.trim();
        if (withoutSpaces.length > 6) {
          return true;
          } else {
          return false;
          }
        };
  const onSubmitForm = (e) => {
    e.preventDefault();
  const isEstudianteValid = validateEstudiante(estudiante);
  const isProgramaValid = validatePrograma(programa);
  if (!isProgramaValid || !isEstudianteValid) {
    alert("Por favor chequea que la información sea correcta");
    } else {
      setMostrarTarjeta(true);
    }
    };
  
  return (
    <div>
        <h1>Campus Virtual UniPioneros</h1>
        {mostrarTarjeta ? (
        <Card estudiante={estudiante} programa={programa} />
        ):(
        <form onSubmit={onSubmitForm}>
            <label htmlFor="Estudiante"></label>
            <input 
                    type="text"
                    placeholder='Ingresar Nombre'
                    id='estudiante'
                    value={estudiante}
                    onChange={onChangeEstudiante}
            />
            <label htmlFor="Programa"></label>
            <input 
                    type="text"
                    placeholder='Ingresar Programa academico'
                    id='programa'
                    value={programa}
                    onChange={onChangePrograma} />
            <button type="submit">Enviar</button>
        </form>
        )}
    </div>
  )
}

export default CampusVirtual